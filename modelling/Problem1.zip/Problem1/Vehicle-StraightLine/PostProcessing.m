%

xc = out.x(:, 1);
x2c = out.x(:, 2);
plot (xc, x2c);