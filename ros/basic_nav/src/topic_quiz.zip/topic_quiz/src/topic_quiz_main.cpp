#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/logging.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

using std::placeholders::_1;

class ScanSubscriber : public rclcpp::Node {
public:
  ScanSubscriber() : Node("scan_subscriber") {
    subscription_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        "scan", 10, std::bind(&ScanSubscriber::scan_callback, this, _1));
    publisher_ =
        this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
  }

private:
  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
    float max_laser_middle = 0;
    float max_laser_left = 0;
    float max_laser_right = 0;

    if (msg->ranges.size() > 0) {
      int middle = (int)msg->ranges.size() / 2;

      for (int i = middle - 10; i < middle + 10; i++) {
        if ((float)msg->ranges[i] < 31) {
          max_laser_middle = std::max(max_laser_middle, (float)msg->ranges[i]);
        }
      }

      for (int i = 0; i < 20; i++) {
        if ((float)msg->ranges[i] < 31) {
          max_laser_left = std::max(max_laser_left, (float)msg->ranges[i]);
        }
      }

      for (int i = msg->ranges.size() - 1; i < msg->ranges.size() - 21; i++) {
        if ((float)msg->ranges[i] < 31) {
          max_laser_right = std::max(max_laser_right, (float)msg->ranges[i]);
        }
      }
      auto cmd_msg = geometry_msgs::msg::Twist();
      // Laser readings
      const float front_distance = max_laser_middle;
      const float left_distance = max_laser_left;
      const float right_distance = max_laser_right;

      // Safety threshold (1 meter)
      const float safe_distance = 1.0;

      // Decision logic
      if (front_distance > safe_distance && left_distance > safe_distance &&
          right_distance > safe_distance) {
        // No obstacles, move forward
        cmd_msg.linear.x = 0.5;
        cmd_msg.angular.z = 0.0;
      } else if (front_distance < safe_distance) {
        // Obstacle in front, turn left
        cmd_msg.linear.x = 0.0;
        cmd_msg.angular.z = 0.5;
      } else if (right_distance < safe_distance) {
        // Obstacle on the right, turn left
        cmd_msg.linear.x = 0.0;
        cmd_msg.angular.z = 0.5;
      } else if (left_distance < safe_distance) {
        // Obstacle on the left, turn right
        cmd_msg.linear.x = 0.0;
        cmd_msg.angular.z = -0.5;
      }

      // Publish the velocity command
      publisher_->publish(cmd_msg);

      //   if (max_laser_middle < 1.1 || max_laser_right < 1.1) {
      //     RCLCPP_INFO(this->get_logger(), "Rading obstacle in front : %f",
      //                 max_laser_middle);

      //     auto message = geometry_msgs::msg::Twist();
      //     message.linear.x = 0.2;
      //     message.angular.z = 0.2;
      //     publisher_->publish(message);
      //   } else if (max_laser_left < 1.1) {
      //     auto message = geometry_msgs::msg::Twist();
      //     message.linear.y = 0.2;
      //     message.angular.z = 0.2;
      //     publisher_->publish(message);
      //   } else {
      //     auto message = geometry_msgs::msg::Twist();
      //     message.linear.x = 1;
      //     message.angular.z = 0;
      //     publisher_->publish(message);
      //   }
    }
  }

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr subscription_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
};

int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ScanSubscriber>());
  rclcpp::shutdown();
  return 0;
}